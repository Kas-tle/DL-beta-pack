# Kinevo Disneyland Project Resource Pack
Minecraft resource pack for the Kinevo Disneyland Project. See the beta server at mcdisney.land or join us on Discord at https://discord.gg/SUqKBRR.
