# Kinevo Disneyland Project Resource Pack
Minecraft resource pack for the Kinevo Disneyland Project. See the beta server at kinevodisney.land or join us on Discord at https://discord.gg/SUqKBRR. See the releases tab for the most up-to-date iteration of the pack. All legally assignable rights are reserved by the creator.
